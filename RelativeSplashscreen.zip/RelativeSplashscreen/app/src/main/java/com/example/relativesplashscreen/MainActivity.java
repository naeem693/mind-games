package com.example.relativesplashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    private static int Splash_time_out=5000;

    //animations
    Animation top_anim,bottom_anim,middle_anim;
    //hooks
    View first,second,third,fourth,fifth,sixth,seven,eight;
    TextView slogan;
    ImageView logo;
    ProgressBar prog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        top_anim = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottom_anim = AnimationUtils.loadAnimation(this,R.anim.bottom_animation);
        middle_anim = AnimationUtils.loadAnimation(this,R.anim.middle_animation);

        //hooks
        first=findViewById(R.id.first_line);
        second=findViewById(R.id.second_line);
        third=findViewById(R.id.third_line);
        fourth=findViewById(R.id.fourth_line);
        fifth=findViewById(R.id.fifth_line);
        sixth=findViewById(R.id.sixth_line);
        seven=findViewById(R.id.seven_line);
        eight=findViewById(R.id.eight_line);
        logo=findViewById(R.id.logo_img);
        slogan = findViewById(R.id.tag_line);
        prog=findViewById(R.id.pro);


        //setting animations
        first.setAnimation(top_anim);
        second.setAnimation(top_anim);
        third.setAnimation(top_anim);
        fourth.setAnimation(top_anim);
        fifth.setAnimation(top_anim);
        sixth.setAnimation(top_anim);
        seven.setAnimation(top_anim);
        eight.setAnimation(top_anim);




        logo.setAnimation(middle_anim);

        prog.setAnimation(top_anim);

        slogan.setAnimation(bottom_anim);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(MainActivity.this,MainActivity2.class);
                Pair[] pairs= new Pair[2];
                pairs[0]=new Pair<View,String>(logo ,"logo_img");
                pairs[1]=new Pair<View,String>(slogan ,"logo_text");
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(MainActivity.this,pairs);




                startActivity(i,options.toBundle());
                finish();

            }
        },Splash_time_out);





    }
}