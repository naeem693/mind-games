package com.example.MindGame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class Signup_Activity extends AppCompatActivity {
    TextInputLayout full_name, username, Reg_email, Reg_password, C_password;
    Button reg_btn, next_activity_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        full_name = findViewById(R.id.full_name);
        username = findViewById(R.id.user_name);
        Reg_email = findViewById(R.id.reg_email);
        Reg_password = findViewById(R.id.reg_password);
        C_password = findViewById(R.id.c_password);
        reg_btn = findViewById(R.id.reg_btn);
        next_activity_btn = findViewById(R.id.next_activity_btn);


        reg_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String FullName = full_name.getEditText().getText().toString().trim();
                String UserName = username.getEditText().getText().toString().trim();
                String Email = Reg_email.getEditText().getText().toString().trim();
                String Pass = Reg_password.getEditText().getText().toString().trim();
                String C_Pass = C_password.getEditText().getText().toString().trim();

                if (!validateName() | !validatePassword() | !validateEmail() | !validateUsername() | confirm_Password() ) {
                    return;
                }


            }
        });


        next_activity_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Signup_Activity.this, Login_Activity.class);

                startActivity(i);
            }
        });


    }

    private Boolean validateName() {
        String val = full_name.getEditText().getText().toString();





        if (val.isEmpty()) {
            full_name.setError("Field cannot be empty");
            return false;
        }
        else  if (val.length() <4){
            full_name.setError("must contain 4 characters");
            return false;



        }

        else {
            full_name.setError(null);
            full_name.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validateUsername() {
        String val = username.getEditText().getText().toString();
        String noWhiteSpace = "\\A\\w{4,20}\\z";

        if (val.isEmpty()) {
            username.setError("Field cannot be empty");
            return false;
        } else if (val.length() >= 15) {
            username.setError("Username too long");
            return false;
        } else if (!val.matches(noWhiteSpace)) {
            username.setError("White Spaces are not allowed");
            return false;
        } else {
            username.setError(null);
            username.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validateEmail() {
        String val = Reg_email.getEditText().getText().toString();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (val.isEmpty()) {
            Reg_email.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailPattern)) {
            Reg_email.setError("Invalid email address");
            return false;
        } else {
            Reg_email.setError(null);
            Reg_email.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validatePassword() {

        String val1 = Reg_password.getEditText().getText().toString();
/*
       String passwordVal = "^" +
                //"(?=.*[0-9])" +         //at least 1 digit
                //"(?=.*[a-z])" +         //at least 1 lower case letter
                //"(?=.*[A-Z])" +         //at least 1 upper case letter
                "(?=.*[a-zA-Z])" +      //any letter
                "(?=\\S+$)" +           //no white spaces
                ".{4,}" +               //at least 4 characters
                "$";
*/

        if (val1.isEmpty()) {
            Reg_password.setError("Field cannot be empty");
            return false;
        } else if (val1.length() <6) {
            Reg_password.setError("Password Must Contain 6 Digits");
            return false;
        } else {
            Reg_password.setError(null);
            Reg_password.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean confirm_Password(){
        String val2 = C_password.getEditText().getText().toString();
        String val3 = Reg_password.getEditText().getText().toString();

        if (val2.isEmpty()) {
            C_password.setError("Field cannot be empty");
            return false;
        }
        else if (!val2.equals(val3)){

            C_password.setError("Password Did Not Match");

            return false;

        }
        else {
            C_password.setError(null);
            C_password.setErrorEnabled(false);
            return true;

        }



    }




}