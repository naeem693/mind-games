package com.example.MindGame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;

public class Login_Activity extends AppCompatActivity {
    Button login_reg_btn, login_btn;
    TextInputLayout Email, Password;


    private Boolean validateEmail() {
        String val = Email.getEditText().getText().toString();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (val.isEmpty()) {
            Email.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailPattern)) {
            Email.setError("Invalid email address");
            return false;
        } else {
            Email.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validatePassword() {
        String val = Password.getEditText().getText().toString();


        if (val.isEmpty()) {
            Password.setError("Field cannot be empty");
            return false;
        } else if (val.length()<6) {
            Password.setError("Password must contain 6 characters");
            return false;
        } else {
            Password.setError(null);
            Password.setErrorEnabled(false);
            return true;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login_reg_btn = findViewById(R.id.next_activity_btn);
        Email = findViewById(R.id.Email);
        Password = findViewById(R.id.password);
        login_btn = findViewById(R.id.login_btn);


        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateEmail();
                validatePassword();


                String email = Email.getEditText().getText().toString().trim();
                String pass = Password.getEditText().getText().toString().trim();


            }
        });


        login_reg_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login_Activity.this, Signup_Activity.class);
                startActivity(i);
            }
        });
    }
}